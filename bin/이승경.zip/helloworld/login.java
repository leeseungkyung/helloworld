package helloworld;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import javax.swing.SpringLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.UIManager;

import DAO.loginDAO;

import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class login { //�α��� 

	private JFrame frame;
	idpwsearch ip;
	loginDAO ld = new loginDAO();
	private JTextField txt_id;
	private JTextField txt_pw;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 671, 523);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JLabel label = new JLabel("\uC2DD\uC0AC\uD569\uC2DC\uB2E4");
		springLayout.putConstraint(SpringLayout.NORTH, label, 25, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, label, 188, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, label, -184, SpringLayout.EAST, frame.getContentPane());
		label.setBackground(new Color(100, 149, 237));
		label.setForeground(new Color(25, 25, 112));
		label.setFont(new Font("HS���ٶ�ü 2.0", Font.BOLD, 60));
		frame.getContentPane().add(label);
		
		JPanel panel = new JPanel();
		springLayout.putConstraint(SpringLayout.SOUTH, label, -6, SpringLayout.NORTH, panel);
		springLayout.putConstraint(SpringLayout.NORTH, panel, 92, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, panel, -25, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, panel, 0, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, panel, 0, SpringLayout.EAST, frame.getContentPane());
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel);
		SpringLayout sl_panel = new SpringLayout();
		panel.setLayout(sl_panel);
		
		JButton btn_join = new JButton("\uD68C\uC6D0\uAC00\uC785");
		sl_panel.putConstraint(SpringLayout.WEST, btn_join, 24, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, btn_join, -178, SpringLayout.SOUTH, panel);
		btn_join.setForeground(new Color(255, 255, 255));
		btn_join.setBackground(new Color(25, 25, 112));
		btn_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
	
				
				
				
				
			
			}
		});
		btn_join.setFont(new Font("HS���ٶ�ü 2.0", Font.PLAIN, 16));
		panel.add(btn_join);
		
		JButton btn_search = new JButton("ID/PW\uCC3E\uAE30");
		sl_panel.putConstraint(SpringLayout.EAST, btn_join, -32, SpringLayout.WEST, btn_search);
		sl_panel.putConstraint(SpringLayout.WEST, btn_search, 190, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, btn_search, -178, SpringLayout.SOUTH, panel);
		btn_search.setForeground(new Color(255, 255, 255));
		btn_search.setBackground(new Color(25, 25, 112));
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //Ŭ�� �� �α���/pw���� â �߱�
				System.out.println("����"); 
				ip = new idpwsearch();
				ip.setVisible(true);
				
			}
		});
		btn_search.setFont(new Font("HS���ٶ�ü 2.0", Font.PLAIN, 16));
		panel.add(btn_search);
		
		JButton btn_login = new JButton("\uB85C\uADF8\uC778");
		sl_panel.putConstraint(SpringLayout.NORTH, btn_search, 43, SpringLayout.SOUTH, btn_login);
		sl_panel.putConstraint(SpringLayout.WEST, btn_login, 219, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.EAST, btn_login, -339, SpringLayout.EAST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, btn_login, -251, SpringLayout.SOUTH, panel);
		btn_login.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) { //�α��� Ŭ�� �̺�Ʈ
			
				boolean cnt = ld.login(txt_id.getText(),txt_pw.getText());
				
				if(cnt==true) {
					System.out.println("success");
					JOptionPane.showMessageDialog(null, "�α��� ����", "�α��� Ȯ��!", JOptionPane.DEFAULT_OPTION);
				} else {
					JOptionPane.showMessageDialog(null, "�α��� ����", "�ٽ� �α��� �ϼ���", JOptionPane.DEFAULT_OPTION);
				}
				
			
			
			
			}
		});
		btn_login.setForeground(new Color(255, 255, 255));
		btn_login.setBackground(new Color(25, 25, 112));
		btn_login.setFont(new Font("HS���ٶ�ü 2.0", Font.PLAIN, 20));
		panel.add(btn_login);
		
		JLabel lblNewLabel_1 = new JLabel("ID :");
		sl_panel.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 41, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, lblNewLabel_1, 38, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.NORTH, btn_login, 0, SpringLayout.NORTH, lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("HS���ٶ�ü 2.0", Font.PLAIN, 20));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("PW :");
		sl_panel.putConstraint(SpringLayout.WEST, lblNewLabel_2, 24, SpringLayout.WEST, panel);
		lblNewLabel_2.setFont(new Font("HS���ٶ�ü 2.0", Font.PLAIN, 20));
		panel.add(lblNewLabel_2);
		
		txt_id = new JTextField();
		sl_panel.putConstraint(SpringLayout.NORTH, txt_id, 41, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, txt_id, 13, SpringLayout.EAST, lblNewLabel_1);
		sl_panel.putConstraint(SpringLayout.EAST, txt_id, -14, SpringLayout.WEST, btn_login);
		panel.add(txt_id);
		txt_id.setColumns(10);
		
		txt_pw = new JTextField();
		sl_panel.putConstraint(SpringLayout.NORTH, btn_join, 43, SpringLayout.SOUTH, txt_pw);
		sl_panel.putConstraint(SpringLayout.WEST, txt_pw, 13, SpringLayout.EAST, lblNewLabel_2);
		sl_panel.putConstraint(SpringLayout.EAST, txt_pw, -14, SpringLayout.WEST, btn_login);
		sl_panel.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 5, SpringLayout.NORTH, txt_pw);
		sl_panel.putConstraint(SpringLayout.NORTH, txt_pw, 84, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, txt_pw, -251, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, txt_id, -12, SpringLayout.NORTH, txt_pw);
		panel.add(txt_pw);
		txt_pw.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		sl_panel.putConstraint(SpringLayout.EAST, btn_search, -6, SpringLayout.WEST, panel_1);
		sl_panel.putConstraint(SpringLayout.WEST, panel_1, 322, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.EAST, panel_1, -10, SpringLayout.EAST, panel);
		panel_1.setBackground(Color.WHITE);
		sl_panel.putConstraint(SpringLayout.NORTH, panel_1, 0, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, panel_1, -10, SpringLayout.SOUTH, panel);
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\pc-19\\Desktop\\main.jpg"));
		panel_1.add(lblNewLabel);
	}
}
