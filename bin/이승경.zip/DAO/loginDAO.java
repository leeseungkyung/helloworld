package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import DTO.loginDTO;

public class loginDAO {

	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	String sql;
	loginDTO ld = new loginDTO();
	
	Scanner sc = new Scanner(System.in);

	private final String url = "jdbc:oracle:thin:@192.168.0.53:1521:xe";
	private final String user = "hello";
	private final String pw = "12345";

	public void getconn() { // ���� �޼ҵ�

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pw);

			if (conn != null) {
				System.out.println("���� ����");
			} else {
				System.out.println("���� ����");
			}

		} catch (Exception e) {

			e.printStackTrace();

		} finally {
			try {
				if (pst != null)
					pst.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
	
//	
//	public int insert(String id, String pw) { //����
//
//		getconn();
//
//		String sql = "insert into member values(?,?,?,?,?,?)";
//
//		try {
//
//			pst = conn.prepareStatement(sql);
//
//			pst.setString(1, id);
//			pst.setString(2, pw);
//
//
//			int cnt = pst.executeUpdate();
//
//			return cnt;
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			close();
//		}
//		return 0;
//	}
//	
	
	
	
	public void close() { //�ݱ�
		try {
			if (rs != null)
				rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			pst.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	
	   public boolean idDoubleCheck(String checkID) { //���̵� �ߺ�üũ
		      try {
		         getconn();
		         sql = "SELECT * FROM member where mid=?";
		         pst = conn.prepareStatement(sql);
		         pst.setString(1, checkID);
		         ResultSet rs = pst.executeQuery();
		         if (rs.next()) {
		            return true;
		         }
		         return false;
		      } catch (SQLException e) {
		         e.printStackTrace();
		      } finally {
		         getFinally();
		      }
		      return false;
		   }
	   
	   
	   

	   //JDBC ���� ����.
	   public void getFinally() {
	      if(pst != null) {
	         try {
	            pst.close();
	         } catch (SQLException e) {
	            e.printStackTrace();
	         }
	      }//pst close
	      if(conn != null) {
	         try {
	            conn.close();
	         } catch (SQLException e) {
	            e.printStackTrace();
	         }
	      }
	   }
	   
	 
	   public boolean login(String checkID, String checkPW) { //�α��� ���
	      try {
	         getconn();
	         sql = "SELECT * FROM member where mid=? and password=?";
	         pst = conn.prepareStatement(sql);
	         pst.setString(1, checkID);
	         pst.setString(2, checkPW);
	         rs = pst.executeQuery();
	         if (rs.next()) {
	            return true;
	         }
	         return false;
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         getFinally();
	      }
	      return false;
	   }
	   
		
		
		
	
	
	
	
	
	
	
}


	
	

