package helloworld;

import java.util.Scanner;

import DAO.loginDAO;

public class main {

	public static void main(String[] args) {
	
		loginDAO ld = new loginDAO();
		
		
		System.out.println("�α���");
		Scanner sc = new Scanner (System.in);
		System.out.print("id :");
		String id = sc.next();
		System.out.print("pw :");
		String pw = sc.next();
		
		if(ld.login(id, pw)==true) {
		System.out.println("�α��� ����");			
		
		}else {
			System.out.println("����");
		}
			
	
		
		
		
		
		
		
		
		
		
		
		

	}

}
