package helloworld;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class idpwsearch extends JDialog { //���̵� ��й�ȣ ã�� - �̽°�

	private final JPanel contentPanel = new JPanel();
	private JTextField txt_birthday;
	private JTextField txt_id;
	private JTextField txt_name;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			idpwsearch dialog = new idpwsearch();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public idpwsearch() {
		setBounds(100, 100, 466, 295);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		SpringLayout sl_contentPanel = new SpringLayout();
		contentPanel.setLayout(sl_contentPanel);
		
		JPanel panel_1 = new JPanel();
		sl_contentPanel.putConstraint(SpringLayout.NORTH, panel_1, 22, SpringLayout.NORTH, contentPanel);
		sl_contentPanel.putConstraint(SpringLayout.WEST, panel_1, 10, SpringLayout.WEST, contentPanel);
		sl_contentPanel.putConstraint(SpringLayout.SOUTH, panel_1, -10, SpringLayout.SOUTH, contentPanel);
		sl_contentPanel.putConstraint(SpringLayout.EAST, panel_1, -28, SpringLayout.EAST, contentPanel);
		panel_1.setBackground(new Color(255, 255, 255));
		contentPanel.add(panel_1);
		SpringLayout sl_panel_1 = new SpringLayout();
		panel_1.setLayout(sl_panel_1);
		
		JPanel panel = new JPanel();
		sl_panel_1.putConstraint(SpringLayout.NORTH, panel, 10, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.WEST, panel, 34, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, panel, -132, SpringLayout.SOUTH, panel_1);
		panel.setBackground(new Color(255, 255, 255));
		panel_1.add(panel);
		
		JPanel panel_2 = new JPanel();
		sl_panel_1.putConstraint(SpringLayout.NORTH, panel_2, 21, SpringLayout.SOUTH, panel);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, panel_2, -11, SpringLayout.SOUTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.EAST, panel, 0, SpringLayout.EAST, panel_2);
		sl_panel_1.putConstraint(SpringLayout.WEST, panel_2, 34, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.EAST, panel_2, -21, SpringLayout.EAST, panel_1);
		panel_2.setForeground(new Color(255, 255, 255));
		panel_2.setBackground(new Color(255, 255, 255));
		SpringLayout sl_panel = new SpringLayout();
		panel.setLayout(sl_panel);
		
		JLabel lb_name = new JLabel("\uC774\uB984 :");
		sl_panel.putConstraint(SpringLayout.NORTH, lb_name, 23, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, lb_name, -263, SpringLayout.EAST, panel);
		lb_name.setForeground(new Color(25, 25, 112));
		lb_name.setFont(new Font("����_Regular", Font.PLAIN, 14));
		panel.add(lb_name);
		
		JButton btn_idsearch = new JButton("ID\uCC3E\uAE30");
		sl_panel.putConstraint(SpringLayout.NORTH, btn_idsearch, -5, SpringLayout.NORTH, lb_name);
		sl_panel.putConstraint(SpringLayout.EAST, btn_idsearch, 0, SpringLayout.EAST, panel);
		btn_idsearch.setForeground(new Color(255, 255, 255));
		btn_idsearch.setBackground(new Color(25, 25, 112));
		btn_idsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_idsearch.setFont(new Font("����_Regular", Font.PLAIN, 15));
		panel.add(btn_idsearch);
		
		txt_name = new JTextField();
		sl_panel.putConstraint(SpringLayout.WEST, btn_idsearch, 14, SpringLayout.EAST, txt_name);
		sl_panel.putConstraint(SpringLayout.NORTH, txt_name, -3, SpringLayout.NORTH, lb_name);
		sl_panel.putConstraint(SpringLayout.WEST, txt_name, 7, SpringLayout.EAST, lb_name);
		txt_name.setForeground(new Color(255, 255, 255));
		txt_name.setColumns(10);
		panel.add(txt_name);
		panel_1.add(panel_2);
		SpringLayout sl_panel_2 = new SpringLayout();
		panel_2.setLayout(sl_panel_2);
		
		JLabel lb_id = new JLabel("ID :");
		sl_panel_2.putConstraint(SpringLayout.EAST, lb_id, -266, SpringLayout.EAST, panel_2);
		lb_id.setBackground(new Color(0, 0, 128));
		lb_id.setForeground(new Color(25, 25, 112));
		sl_panel_2.putConstraint(SpringLayout.NORTH, lb_id, 22, SpringLayout.NORTH, panel_2);
		lb_id.setFont(new Font("����_Regular", Font.PLAIN, 14));
		panel_2.add(lb_id);
		
		JLabel lb_birth = new JLabel("\uC0DD\uB144\uC6D4\uC77C :");
		sl_panel_2.putConstraint(SpringLayout.NORTH, lb_birth, 22, SpringLayout.SOUTH, lb_id);
		lb_birth.setForeground(new Color(25, 25, 112));
		sl_panel_2.putConstraint(SpringLayout.EAST, lb_birth, 0, SpringLayout.EAST, lb_id);
		lb_birth.setFont(new Font("����_Regular", Font.PLAIN, 14));
		panel_2.add(lb_birth);
		
		txt_birthday = new JTextField();
		sl_panel_2.putConstraint(SpringLayout.NORTH, txt_birthday, -3, SpringLayout.NORTH, lb_birth);
		sl_panel_2.putConstraint(SpringLayout.WEST, txt_birthday, 6, SpringLayout.EAST, lb_birth);
		txt_birthday.setForeground(new Color(255, 255, 255));
		txt_birthday.setColumns(10);
		panel_2.add(txt_birthday);
		
		JButton btn_pwsearch = new JButton("\uBE44\uBC00\uBC88\uD638 \uCC3E\uAE30");
		sl_panel_2.putConstraint(SpringLayout.WEST, btn_pwsearch, 17, SpringLayout.EAST, txt_birthday);
		sl_panel_2.putConstraint(SpringLayout.EAST, btn_pwsearch, 0, SpringLayout.EAST, panel_2);
		btn_pwsearch.setForeground(new Color(255, 255, 255));
		btn_pwsearch.setBackground(new Color(25, 25, 112));
		sl_panel_2.putConstraint(SpringLayout.SOUTH, btn_pwsearch, -24, SpringLayout.SOUTH, panel_2);
		sl_panel_2.putConstraint(SpringLayout.NORTH, btn_pwsearch, 22, SpringLayout.NORTH, panel_2);
		btn_pwsearch.setFont(new Font("����_Regular", Font.PLAIN, 15));
		panel_2.add(btn_pwsearch);
		
		txt_id = new JTextField();
		sl_panel_2.putConstraint(SpringLayout.NORTH, txt_id, -3, SpringLayout.NORTH, lb_id);
		sl_panel_2.putConstraint(SpringLayout.WEST, txt_id, 6, SpringLayout.EAST, lb_id);
		txt_id.setForeground(new Color(255, 255, 255));
		txt_id.setColumns(10);
		panel_2.add(txt_id);
	}
	
	

}
